<?php
$nome = "Bolo";
$valor = $_REQUEST["tipobolo"];
$expira = time() + 3600;
setcookie($nome, $valor, $expira);

if($_POST['tipobolo'] == "Bolo de Chocolate"){
  $msg = '<img src="bolos/Bolo de Chocolate.jpg" width="400" height="350"><br>';
  $descricao = "<label> Delicioso bolo confeitado com cobertura de chocolate ao leite derretido e recheio de sabor brigadeiro </label>";
}

else if($_POST['tipobolo'] == "Bolo de Chocolate com Morangos"){
  $msg = '<img src="bolos/Bolo de Chocolate com Morangos.jpg" width="400" height="350"><br>';
  $descricao = "<label> Apetitoso bolo de chocolate com cobertura cremosa de chocolate e decorado com morangos inteiros. Além da massa feita com beterraba e recheio de mousse de morango </label>";
}
  
else if($_POST['tipobolo'] == "Bolo de Chocolate com Laranja"){
  $msg = '<img src="bolos/Bolo de Chocolate com Laranja.jpg" width="400" height="350"><br>';
  $descricao = "<label> Saboroso bolo de chocolate com cobertura de chocolate amargo, massa com sabor laranja e recheio de sabor abacaxi. Aos alérgicos: sem glúten e sem lactose </label>";
}

else if($_POST['tipobolo'] == "Bolo de Morango"){
  $msg = '<img src="bolos/Bolo de Morango.jpg" width="400" height="350"><br>';
  $descricao = "<label> Bolo tamanho pequeno (7 pessoas) com cobertura de glacê decorada com morangos fatiados e recheio sabor morango </label>";
}
  
else if($_POST['tipobolo'] == "Bolo de Morango 2"){
  $msg = '<img src="bolos/Bolo de Morango 2.jpg" width="400" height="350"><br>';
  $descricao = "<label> Bolo tamanho médio (15 pessoas) com cobertura de glacê decorada com morangos fatiados e recheio sabor morango </label>";
}

else if($_POST['tipobolo'] == "Bolo de Morango 3"){
  $msg = '<img src="bolos/Bolo de Morango 3.jpg" width="400" height="350"><br>';
  $descricao = "<label> Bolo tamanho grande (20 pessoas) com cobertura de glacê decorada com folhas de hortelã e frutas fatiadas (morangos e bananas) com massa macia e recheios sabores doce de leite e morango </label>";
}

echo "<div class = 'center_images'>";
echo "<h1> Bolo escolhido </h1>";
echo $msg;
echo "</div>";
echo "<div class = 'center_images'>";
echo "<h1> Descrição </h1>";
echo $descricao;
echo "</div><br>"

?>
<html>
<head>
  <link rel="stylesheet" href="style.css">
  <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
  <title>Dados do pedido</title>
  </head>
  <body>
  
  <form action="insert.php" method="post">
  <div class = "center_button">
  <h1> Dados do cliente </h1>
  </div>
    <div class = "center_button">
    	<label>Qual o seu nome?</label><br><br>
        <input type="text" name="nome" id="nome" placeholder = "Digite"><br><br>
    
    	<label>E-mail para contato</label><br><br>
        <input type="text" name="email" id="email" placeholder = "Digite"><br><br>
    
    	<label>Telefone para contato</label><br><br>
        <input type="text" name="telefone" id="telefone" placeholder = "Digite"><br><br>
      
        <label>Em quantas fatias você gostaria de cortar o bolo?</label><br><br>
        <input type="text" name="num_fatias" id="num_fatias" placeholder = "Digite"><br><br>

    	<label>Observações</label><br><br>
        <input type="text" name="mensagem" id="mensagem" placeholder = "Escreva"><br><br>
      
    <div class="buttons">
      <button type="submit" formaction="insert.php" class = "button">Enviar pedido</button>
    </div>
    </div>
</form>
</body>
</html>